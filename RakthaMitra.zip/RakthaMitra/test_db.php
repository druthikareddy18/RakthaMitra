
<?php
require_once "db.php";

echo "RakthaMitra Database Connected Successfully!";
?>
